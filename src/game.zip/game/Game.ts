import { Engine, Scene } from '@babylonjs/core';
import { ArenaScene } from './scenes/ArenaScene';

export class Game {
  private readonly engine: Engine;
  private scene: Scene | null = null;
  private arena: ArenaScene | null = null;

  constructor(private readonly canvas: HTMLCanvasElement) {
    if (!Engine.isSupported()) {
      throw new Error('WebGL is not available in this browser.');
    }
    this.engine = new Engine(canvas, true, {
      preserveDrawingBuffer: false,
      stencil: false,
      antialias: true
    });
  }

  /** The active Babylon scene, available after `start()`. Used by the loading screen. */
  get activeScene(): Scene | null {
    return this.scene;
  }

  start(): void {
    this.arena = new ArenaScene(this.engine, this.canvas);
    this.scene = this.arena.scene;

    this.engine.runRenderLoop(() => {
      this.arena?.update();
      this.scene?.render();
    });

    window.addEventListener('resize', this.onResize);
  }

  dispose(): void {
    window.removeEventListener('resize', this.onResize);
    this.arena?.dispose();
    this.scene?.dispose();
    this.engine.dispose();
  }

  private onResize = (): void => {
    this.engine.resize();
  };
}
